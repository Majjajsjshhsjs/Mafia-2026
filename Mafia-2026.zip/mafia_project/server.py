#!/usr/bin/env python3
import json, os, random, secrets, sqlite3, string, threading, time, csv, io
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, 'data', 'mafia.db')
HOST = os.environ.get('MAFIA_HOST', '0.0.0.0')
PORT = int(os.environ.get('MAFIA_PORT', '8000'))

ROLE_NAMES = ['Мирный житель', 'Мафия', 'Комиссар', 'Доктор', 'Дон']
ROLE_TEAM = {'Мирный житель':'town','Мафия':'mafia','Комиссар':'town','Доктор':'town','Дон':'mafia'}

os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
DB_LOCK = threading.RLock()

def db():
    c = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with DB_LOCK, db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS rooms(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, phase TEXT NOT NULL DEFAULT 'lobby', phase_started REAL, phase_duration INTEGER DEFAULT 120, paused INTEGER DEFAULT 0, version INTEGER DEFAULT 0, round_no INTEGER DEFAULT 0, created_at REAL NOT NULL, finished_at REAL);
        CREATE TABLE IF NOT EXISTS players(id INTEGER PRIMARY KEY AUTOINCREMENT, room_id INTEGER NOT NULL, token TEXT UNIQUE NOT NULL, name TEXT NOT NULL, role TEXT, alive INTEGER NOT NULL DEFAULT 1, connected INTEGER NOT NULL DEFAULT 1, is_host INTEGER NOT NULL DEFAULT 0, joined_at REAL NOT NULL, last_seen REAL NOT NULL, FOREIGN KEY(room_id) REFERENCES rooms(id));
        CREATE TABLE IF NOT EXISTS votes(id INTEGER PRIMARY KEY AUTOINCREMENT, room_id INTEGER NOT NULL, round_no INTEGER NOT NULL, voter_id INTEGER NOT NULL, target_id INTEGER NOT NULL, created_at REAL NOT NULL, UNIQUE(room_id, round_no, voter_id));
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, room_id INTEGER NOT NULL, type TEXT NOT NULL, payload TEXT NOT NULL, created_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY AUTOINCREMENT, room_id INTEGER NOT NULL, player_id INTEGER, name TEXT NOT NULL, message TEXT NOT NULL, created_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS games(id INTEGER PRIMARY KEY AUTOINCREMENT, room_id INTEGER NOT NULL, started_at REAL NOT NULL, finished_at REAL, winner TEXT, players_json TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS stats(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, games INTEGER DEFAULT 0, wins INTEGER DEFAULT 0, mafia_roles INTEGER DEFAULT 0, town_roles INTEGER DEFAULT 0);
        ''')
        try: c.execute('ALTER TABLE rooms ADD COLUMN round_no INTEGER DEFAULT 0')
        except sqlite3.OperationalError: pass
init_db()

def now(): return time.time()
def bump(room_id):
    with DB_LOCK, db() as c:
        c.execute('UPDATE rooms SET version=version+1 WHERE id=?',(room_id,))

def event(room_id, typ, payload):
    with DB_LOCK, db() as c:
        c.execute('INSERT INTO events(room_id,type,payload,created_at) VALUES(?,?,?,?)',(room_id,typ,json.dumps(payload,ensure_ascii=False),now()))
        c.execute('UPDATE rooms SET version=version+1 WHERE id=?',(room_id,))

def room_by_code(code):
    with DB_LOCK, db() as c: return c.execute('SELECT * FROM rooms WHERE code=?',(code.upper(),)).fetchone()

def make_code():
    alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    while True:
        code=''.join(random.choice(alphabet) for _ in range(random.choice([4,5,6])))
        if not room_by_code(code): return code

def clean_name(s):
    s=' '.join(str(s or '').strip().split())
    return s[:30]

def current_round(room_id):
    with DB_LOCK, db() as c:
        r=c.execute('SELECT COALESCE(MAX(round_no),0) n FROM votes WHERE room_id=?',(room_id,)).fetchone()
        return int(r['n'])

def public_state(room_id, token=None):
    with DB_LOCK, db() as c:
        room=c.execute('SELECT * FROM rooms WHERE id=?',(room_id,)).fetchone()
        ps=c.execute('SELECT id,name,role,alive,connected,is_host FROM players WHERE room_id=? ORDER BY id',(room_id,)).fetchall()
        me=c.execute('SELECT * FROM players WHERE room_id=? AND token=?',(room_id,token)).fetchone() if token else None
        round_no=int(room['round_no'] or 0)
        votes=c.execute('SELECT voter_id,target_id FROM votes WHERE room_id=? AND round_no=?',(room_id,round_no)).fetchall()
        chat=c.execute('SELECT name,message,created_at FROM chats WHERE room_id=? ORDER BY id DESC LIMIT 50',(room_id,)).fetchall()
        events=c.execute('SELECT type,payload,created_at FROM events WHERE room_id=? ORDER BY id DESC LIMIT 100',(room_id,)).fetchall()
    t=now(); remaining=max(0, int((room['phase_started'] or t)+(room['phase_duration'] or 0)-t)) if room['phase']!='lobby' and not room['paused'] else int(room['phase_duration'] or 0)
    if room['paused'] and room['phase_started']:
        remaining=max(0,int(room['phase_duration']))
    players=[]
    for p in ps:
        d={'id':p['id'],'name':p['name'],'alive':bool(p['alive']),'connected':bool(p['connected']),'is_host':bool(p['is_host'])}
        if me and (p['id']==me['id'] or me['is_host']): d['role']=p['role']
        players.append(d)
    return {'room':{'code':room['code'],'phase':room['phase'],'paused':bool(room['paused']),'remaining':remaining,'version':room['version'],'round':round_no},'me':({'id':me['id'],'name':me['name'],'role':me['role'],'alive':bool(me['alive']),'is_host':bool(me['is_host'])} if me else None),'players':players,'votes':[dict(v) for v in votes],'chat':[dict(x) for x in reversed(chat)],'events':[{'type':x['type'],'payload':json.loads(x['payload']),'created_at':x['created_at']} for x in reversed(events)]}

def json_resp(h, obj, status=200):
    raw=json.dumps(obj,ensure_ascii=False).encode(); h.send_response(status); h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Content-Length',str(len(raw))); h.end_headers(); h.wfile.write(raw)

def body(h):
    n=int(h.headers.get('Content-Length','0')); return json.loads(h.rfile.read(n) or b'{}')

def require_player(data):
    code=str(data.get('code','')).upper(); token=data.get('token',''); room=room_by_code(code)
    if not room: raise ValueError('Комната не найдена')
    with DB_LOCK, db() as c: p=c.execute('SELECT * FROM players WHERE room_id=? AND token=?',(room['id'],token)).fetchone()
    if not p: raise ValueError('Недействительный токен игрока')
    with DB_LOCK, db() as c: c.execute('UPDATE players SET last_seen=?,connected=1 WHERE id=?',(now(),p['id']))
    return room,p

def assign_roles(n):
    # Balanced default; configured by player count. At least one mafia, and special roles only when enough players.
    mafia=max(1, n//4)
    roles=['Мафия']*mafia
    if n>=7: roles.append('Дон')
    if n>=5: roles.append('Комиссар')
    if n>=6: roles.append('Доктор')
    while len(roles)<n: roles.append('Мирный житель')
    random.shuffle(roles); return roles

def api(path, method, data):
    if path=='/api/create' and method=='POST':
        name=clean_name(data.get('host_name'))
        if not name: raise ValueError('Введите имя ведущего')
        with DB_LOCK, db() as c:
            code=make_code(); t=secrets.token_urlsafe(24); ts=now()
            cur=c.execute('INSERT INTO rooms(code,phase,phase_started,created_at) VALUES(?,?,?,?,?)'.replace('?,?,?,?,?','?,?,?,?'),(code,'lobby',ts,ts)); rid=cur.lastrowid
            c.execute('INSERT INTO players(room_id,token,name,is_host,joined_at,last_seen) VALUES(?,?,?,?,?,?)',(rid,t,name,1,ts,ts))
        return {'ok':True,'code':code,'token':t,'state':public_state(rid,t)}
    if path=='/api/join' and method=='POST':
        code=str(data.get('code','')).strip().upper(); name=clean_name(data.get('name')); old=data.get('token')
        room=room_by_code(code)
        if not room: raise ValueError('Комната не найдена')
        with DB_LOCK, db() as c:
            if old:
                p=c.execute('SELECT * FROM players WHERE room_id=? AND token=?',(room['id'],old)).fetchone()
                if p:
                    c.execute('UPDATE players SET name=?,connected=1,last_seen=? WHERE id=?',(name or p['name'],now(),p['id']))
                    return {'ok':True,'code':code,'token':old,'state':public_state(room['id'],old)}
            count=c.execute('SELECT COUNT(*) n FROM players WHERE room_id=?',(room['id'],)).fetchone()['n']
            if count>=20: raise ValueError('В комнате уже 20 игроков')
            if room['phase']!='lobby': raise ValueError('Партия уже началась; используйте повторный вход')
            if not name: raise ValueError('Введите имя')
            t=secrets.token_urlsafe(24); ts=now(); c.execute('INSERT INTO players(room_id,token,name,joined_at,last_seen) VALUES(?,?,?,?,?)',(room['id'],t,name,ts,ts))
        event(room['id'],'join',{'name':name}); return {'ok':True,'code':code,'token':t,'state':public_state(room['id'],t)}
    if path=='/api/state' and method=='POST':
        room,p=require_player(data); return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/start' and method=='POST':
        room,p=require_player(data)
        if not p['is_host']: raise ValueError('Только ведущий может начать игру')
        with DB_LOCK, db() as c:
            players=c.execute('SELECT * FROM players WHERE room_id=? ORDER BY id',(room['id'],)).fetchall()
            if not 4<=len(players)<=20: raise ValueError('Для старта нужно от 4 до 20 игроков')
            roles=assign_roles(len(players))
            for pl,role in zip(players,roles): c.execute('UPDATE players SET role=?,alive=1 WHERE id=?',(role,pl['id']))
            c.execute('UPDATE rooms SET phase=?,phase_started=?,phase_duration=?,paused=0,round_no=0,finished_at=NULL WHERE id=?',('night',now(),120,room['id']))
            c.execute('INSERT INTO games(room_id,started_at,players_json) VALUES(?,?,?)',(room['id'],now(),json.dumps([dict(pl) for pl in players],default=str)))
        event(room['id'],'phase',{'phase':'night'}); return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/phase' and method=='POST':
        room,p=require_player(data)
        if not p['is_host']: raise ValueError('Только ведущий')
        phase=data.get('phase'); dur=max(5,min(3600,int(data.get('duration',120))))
        if phase not in ['night','day','lobby']: raise ValueError('Неверная фаза')
        with DB_LOCK, db() as c:
            r=c.execute('SELECT round_no FROM rooms WHERE id=?',(room['id'],)).fetchone(); rn=int(r['round_no'] or 0) + (1 if phase=='day' else 0)
            c.execute('UPDATE rooms SET phase=?,phase_started=?,phase_duration=?,paused=0,round_no=? WHERE id=?',(phase,now(),dur,rn,room['id']))
        event(room['id'],'phase',{'phase':phase}); return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/pause' and method=='POST':
        room,p=require_player(data)
        if not p['is_host']: raise ValueError('Только ведущий')
        with DB_LOCK, db() as c:
            r=c.execute('SELECT * FROM rooms WHERE id=?',(room['id'],)).fetchone()
            paused=not bool(r['paused'])
            if paused:
                rem=max(0,(r['phase_started'] or now())+r['phase_duration']-now()); c.execute('UPDATE rooms SET paused=1,phase_duration=? WHERE id=?',(int(rem),room['id']))
            else: c.execute('UPDATE rooms SET paused=0,phase_started=? WHERE id=?',(now(),room['id']))
        event(room['id'],'pause',{'paused':paused}); return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/vote' and method=='POST':
        room,p=require_player(data)
        if not p['alive']: raise ValueError('Выбывший игрок не может голосовать')
        if room['phase']!='day': raise ValueError('Голосование доступно только днём')
        target=int(data.get('target_id'))
        with DB_LOCK, db() as c:
            rnd=int(c.execute('SELECT round_no FROM rooms WHERE id=?',(room['id'],)).fetchone()['round_no'] or 1)
            exists=c.execute('SELECT 1 FROM votes WHERE room_id=? AND round_no=? AND voter_id=?',(room['id'],rnd,p['id'])).fetchone()
            if exists: raise ValueError('Вы уже голосовали')
            tp=c.execute('SELECT * FROM players WHERE room_id=? AND id=?',(room['id'],target)).fetchone()
            if not tp or not tp['alive']: raise ValueError('Цель недоступна')
            c.execute('INSERT INTO votes(room_id,round_no,voter_id,target_id,created_at) VALUES(?,?,?,?,?)',(room['id'],rnd,p['id'],target,now()))
        event(room['id'],'vote',{'voter':p['name'],'target_id':target}); return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/execute' and method=='POST':
        room,p=require_player(data)
        if not p['is_host']: raise ValueError('Только ведущий')
        target=int(data.get('target_id')); with_db=None
        with DB_LOCK, db() as c:
            tp=c.execute('SELECT * FROM players WHERE room_id=? AND id=?',(room['id'],target)).fetchone()
            if not tp or not tp['alive']: raise ValueError('Игрок недоступен')
            c.execute('UPDATE players SET alive=0 WHERE id=?',(target,))
        event(room['id'],'death',{'player_id':target,'name':tp['name'],'reason':'казнь'})
        return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/status' and method=='POST':
        room,p=require_player(data)
        if not p['is_host']: raise ValueError('Только ведущий')
        target=int(data.get('player_id')); alive=bool(data.get('alive'))
        with DB_LOCK, db() as c: c.execute('UPDATE players SET alive=? WHERE room_id=? AND id=?',(1 if alive else 0,room['id'],target))
        event(room['id'],'status',{'player_id':target,'alive':alive}); return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/chat' and method=='POST':
        room,p=require_player(data); msg=str(data.get('message','')).strip()[:500]
        if not msg: raise ValueError('Пустое сообщение')
        with DB_LOCK, db() as c: c.execute('INSERT INTO chats(room_id,player_id,name,message,created_at) VALUES(?,?,?,?,?)',(room['id'],p['id'],p['name'],msg,now()))
        bump(room['id']); return {'ok':True}
    if path=='/api/end' and method=='POST':
        room,p=require_player(data)
        if not p['is_host']: raise ValueError('Только ведущий')
        with DB_LOCK, db() as c:
            winner=data.get('winner') or 'не определён'; c.execute('UPDATE rooms SET phase=?,finished_at=? WHERE id=?',('finished',now(),room['id']))
            g=c.execute('SELECT * FROM games WHERE room_id=? AND finished_at IS NULL ORDER BY id DESC LIMIT 1',(room['id'],)).fetchone()
            if g: c.execute('UPDATE games SET finished_at=?,winner=? WHERE id=?',(now(),winner,g['id']))
            players=c.execute('SELECT name,role FROM players WHERE room_id=?',(room['id'],)).fetchall()
            for x in players:
                st=c.execute('SELECT * FROM stats WHERE name=?',(x['name'],)).fetchone()
                mafia=ROLE_TEAM.get(x['role'])=='mafia'
                if st: c.execute('UPDATE stats SET games=games+1, wins=wins+?, mafia_roles=mafia_roles+?, town_roles=town_roles+? WHERE name=?',(1 if (winner=='mafia' and mafia) or (winner=='town' and not mafia) else 0,1 if mafia else 0,0 if mafia else 1,x['name']))
                else: c.execute('INSERT INTO stats(name,games,wins,mafia_roles,town_roles) VALUES(?,?,?,?,?)',(x['name'],1,1 if (winner=='mafia' and mafia) or (winner=='town' and not mafia) else 0,1 if mafia else 0,0 if mafia else 1))
        event(room['id'],'finished',{'winner':winner}); return {'ok':True,'state':public_state(room['id'],p['token'])}
    if path=='/api/stats' and method=='POST':
        room,p=require_player(data)
        with DB_LOCK, db() as c: rows=c.execute('SELECT name,games,wins,mafia_roles,town_roles FROM stats ORDER BY wins DESC,games DESC,name').fetchall()
        return {'ok':True,'stats':[dict(x) for x in rows]}
    if path=='/api/export' and method=='POST':
        room,p=require_player(data)
        if not p['is_host']: raise ValueError('Только ведущий')
        with DB_LOCK, db() as c:
            rows=c.execute('SELECT g.id,g.started_at,g.finished_at,g.winner,p.name,p.role,p.alive FROM games g JOIN players p ON p.room_id=g.room_id WHERE g.room_id=? ORDER BY g.id',(room['id'],)).fetchall()
        out=io.StringIO(); w=csv.writer(out); w.writerow(['game_id','started_at','finished_at','winner','player','role','alive']); w.writerows([list(x) for x in rows])
        return {'ok':True,'csv':out.getvalue()}
    raise ValueError('Неизвестный запрос')

class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*a): pass
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/' or path=='/index.html': return self.static('static/index.html','text/html; charset=utf-8')
        if path.startswith('/static/'):
            rel=path[len('/static/'):].replace('..',''); fp=os.path.join(BASE,'static',rel)
            if os.path.isfile(fp):
                typ='text/plain; charset=utf-8'
                if fp.endswith('.css'): typ='text/css; charset=utf-8'
                if fp.endswith('.js'): typ='application/javascript; charset=utf-8'
                return self.static(fp,typ,absolute=True)
        self.send_error(404)
    def static(self, fp, typ, absolute=False):
        try:
            data=open(fp if absolute else os.path.join(BASE,fp),'rb').read()
            self.send_response(200); self.send_header('Content-Type',typ); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        except: self.send_error(404)
    def do_POST(self):
        try:
            data=body(self); result=api(urlparse(self.path).path,'POST',data); json_resp(self,result)
        except Exception as e: json_resp(self,{'ok':False,'error':str(e)},400)

def phase_watcher():
    while True:
        time.sleep(1)
        with DB_LOCK, db() as c:
            rooms=c.execute("SELECT * FROM rooms WHERE phase IN ('night','day') AND paused=0").fetchall()
            for r in rooms:
                if r['phase_started'] and now() >= r['phase_started'] + r['phase_duration']:
                    nxt='day' if r['phase']=='night' else 'night'
                    dur=180 if nxt=='day' else 120
                    rn=int(r['round_no'] or 0)+(1 if nxt=='day' else 0)
                    c.execute('UPDATE rooms SET phase=?,phase_started=?,phase_duration=?,round_no=?,version=version+1 WHERE id=?',(nxt,now(),dur,rn,r['id']))
                    c.execute('INSERT INTO events(room_id,type,payload,created_at) VALUES(?,?,?,?)',(r['id'],'phase',json.dumps({'phase':nxt},ensure_ascii=False),now()))

def mark_disconnected():
    while True:
        time.sleep(5)
        cutoff=now()-12
        with DB_LOCK, db() as c: c.execute('UPDATE players SET connected=0 WHERE last_seen<?',(cutoff,))

if __name__=='__main__':
    threading.Thread(target=mark_disconnected,daemon=True).start()
    threading.Thread(target=phase_watcher,daemon=True).start()
    print(f'Mafia-2026 server: http://127.0.0.1:{PORT}')
    print('Для LAN используйте адрес компьютера ведущего, например http://192.168.1.10:8000')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
